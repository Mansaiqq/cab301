﻿//2024 CAB301 Assignment 3 
//TransportationNetwok.cs
//Assignment3B-TransportationNetwork

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public partial class TransportationNetwork
{

    private string[]? intersections; //array storing the names of those intersections in this transportation network design
    private int[,]? distances; //adjecency matrix storing distances between each pair of intersections, if there is a road linking the two intersections

    public string[]? Intersections
    {
        get {return intersections;}
    }

    public int[,]? Distances
    {
        get { return distances; }
    }


    //Read information about a transportation network plan into the system
    //Preconditions: The given file exists at the given path and the file is not empty
    //Postconditions: Return true, if the information about the transportation network plan is read into the system, the intersections are stored in the class field, intersections, and the distances of the links between the intersections are stored in the class fields, distances;
    //                otherwise, return false and both intersections and distances are null.
    public bool ReadFromFile(string filePath)
{
    try
    {
        var lines = File.ReadAllLines(filePath);
        var intersectionsSet = new HashSet<string>();
        var edges = new List<Tuple<string, string, int>>();

        foreach (var line in lines)
        {
            var parts = line.Split(',');
            if (parts.Length != 3)
                return false; // 無効な行

            var from = parts[0].Trim();
            var to = parts[1].Trim();
            var weight = int.Parse(parts[2].Trim());

            intersectionsSet.Add(from);
            intersectionsSet.Add(to);
            edges.Add(new Tuple<string, string, int>(from, to, weight));
        }

        intersections = intersectionsSet.ToArray();
        Array.Sort(intersections); // 順序を維持

        var n = intersections.Length;
        distances = new int[n, n];

        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                distances[i, j] = (i == j) ? 0 : int.MaxValue;

        foreach (var edge in edges)
        {
            var fromIndex = Array.IndexOf(intersections, edge.Item1);
            var toIndex = Array.IndexOf(intersections, edge.Item2);
            distances[fromIndex, toIndex] = edge.Item3;
        }

        return true;
    }
    catch
    {
        intersections = null;
        distances = null;
        return false;
    }
}



    //Display the transportation network plan with intersections and distances between intersections
    //Preconditions: The given file exists at the given path and the file is not empty
    //Postconditions: The transportation netork is displayed in a matrix format
    public void DisplayTransportNetwork()
    {
        Console.Write("       ");
        for (int i = 0; i < intersections?.Length; i++)
        {
                    Console.Write(intersections[i].ToString().PadRight(5) + "  ");
        }
        Console.WriteLine();


        for (int i = 0; i < distances?.GetLength(0); i++)
        {
            Console.Write(intersections[i].ToString().PadRight(5) + "  ");
            for (int j = 0; j < distances?.GetLength(1); j++)
            {
                if (distances[i, j] == Int32.MaxValue)
                    Console.Write("INF  " + "  ");
                else
                    Console.Write(distances[i, j].ToString().PadRight(5)+"  ");
            }
            Console.WriteLine();
        }
    }


    //Check if this transportation network is strongly connected. A transportation network is strongly connected, if there is a path from any intersection to any other intersections in thihs transportation network. 
    //Precondition: Transportation network plan data have been read into the system.
    //Postconditions: return true, if this transpotation netork is strongly connected; otherwise, return false. This transportation network remains unchanged.
public bool IsConnected()
{
    if (intersections == null || distances == null)
        return false;

    var n = intersections.Length;
    for (int i = 0; i < n; i++)
    {
        var visited = new bool[n];
        DFS(i, visited);

        if (visited.Contains(false))
            return false;
    }

    return true;
}

private void DFS(int node, bool[] visited)
{
    visited[node] = true;
    for (int i = 0; i < distances.GetLength(1); i++)
    {
        if (distances[node, i] != int.MaxValue && !visited[i])
        {
            DFS(i, visited);
        }
    }
}

    
    
    //Find the shortest path between a pair of intersections
    //Precondition: transportation network plan data have been read into the system
    //Postcondition: return the shorest distance between two different intersections; return 0 if there is no path from startVerte to endVertex; returns -1 if startVertex or endVertex does not exists. This transportation network remains unchanged.

    public int FindShortestDistance(string startVertex, string endVertex)
{
    if (intersections == null || distances == null)
        return -1;

    int startIndex = Array.IndexOf(intersections, startVertex);
    int endIndex = Array.IndexOf(intersections, endVertex);

    if (startIndex == -1 || endIndex == -1)
        return -1;

    var n = intersections.Length;
    var dist = new int[n];
    var visited = new bool[n];

    for (int i = 0; i < n; i++)
        dist[i] = int.MaxValue;

    dist[startIndex] = 0;

    for (int count = 0; count < n - 1; count++)
    {
        int u = MinDistance(dist, visited);
        visited[u] = true;

        for (int v = 0; v < n; v++)
        {
            if (!visited[v] && distances[u, v] != int.MaxValue && dist[u] != int.MaxValue && dist[u] + distances[u, v] < dist[v])
            {
                dist[v] = dist[u] + distances[u, v];
            }
        }
    }

    return dist[endIndex] == int.MaxValue ? 0 : dist[endIndex];
}

private int MinDistance(int[] dist, bool[] visited)
{
    int min = int.MaxValue, minIndex = -1;

    for (int v = 0; v < dist.Length; v++)
    {
        if (!visited[v] && dist[v] <= min)
        {
            min = dist[v];
            minIndex = v;
        }
    }

    return minIndex;
}

    //Find the shortest path between all pairs of intersections
    //Precondition: transportation network plan data have been read into the system
    //Postcondition: return the shorest distances between between all pairs of intersections through a two-dimensional int array and this transportation network remains unchanged

    public int[,] FindAllShortestDistances()
{
    if (intersections == null || distances == null)
        return null;

    int n = intersections.Length;
    int[,] dist = new int[n, n];
    Array.Copy(distances, dist, distances.Length);

    for (int k = 0; k < n; k++)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (dist[i, k] != int.MaxValue && dist[k, j] != int.MaxValue && dist[i, k] + dist[k, j] < dist[i, j])
                {
                    dist[i, j] = dist[i, k] + dist[k, j];
                }
            }
        }
    }

    return dist;
}
}